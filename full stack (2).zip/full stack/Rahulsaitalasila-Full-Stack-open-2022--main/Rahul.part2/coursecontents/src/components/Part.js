import React from 'react'

const Part = ({part, exercises}) =>
  <p>
    {part} {exercises}
  </p>

export default Part